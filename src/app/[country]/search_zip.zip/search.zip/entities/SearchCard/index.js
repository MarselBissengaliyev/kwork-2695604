import SearchCard from "./ui/SearchCard";
import SearchCardSmall from "./ui/SearchCardSmall";
import SearchCardMobile from "./ui/SearchCardMobile";
export default { SearchCardSmall, SearchCard, SearchCardMobile };

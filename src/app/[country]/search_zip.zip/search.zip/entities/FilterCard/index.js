import FilterCardContent from "./ui/FilterCardContent";
export default FilterCardContent;
